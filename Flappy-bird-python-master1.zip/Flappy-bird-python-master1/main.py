import pygame, random, time
from pygame.locals import *
import random as rd
#VARIABLES
class VARIABLES:
    SW = 600
    SH = 800
    SPD = 20
    G = 2
    GSPD = 20
    GW = 2 * SH
    GH= 20
    PW = 80
    PH = 500
    PG = 150


pygame.mixer.init()


class Bird(pygame.sprite.Sprite):
    def start(self):
        self.current_image = (self.current_image + 1) % 3
        self.image = self.images[self.current_image]

    def jump(self):
        self.speed = - VARIABLES.G * 10

    def update(self):
        self.current_image = (self.current_image + 1) % 3
        self.image = self.images[self.current_image]
        self.speed += VARIABLES.G
        self.rect[1] += self.speed

    def __init__(self):
        pygame.sprite.Sprite.__init__(self)

        self.images =  [pygame.image.load('imges/bird3.png'),
                        pygame.image.load('imges/bird2.png'),
                        pygame.image.load('imges/bird1.png')]

        self.speed = VARIABLES.SPD

        self.current_image = 0
        self.image = pygame.image.load('imges/bird3.png')
        self.mask = pygame.mask.from_surface(self.image)

        self.rect = self.image.get_rect()
        self.rect[0] = VARIABLES.SW / 6
        self.rect[1] = VARIABLES.SH / 2



class Pipe(pygame.sprite.Sprite):

    def __init__(self, inverted, xpos, ysize):
        pygame.sprite.Sprite.__init__(self)

        self. image = pygame.image.load('imges/colonna.png')
        self.image = pygame.transform.scale(self.image, (VARIABLES.PW, VARIABLES.PH))


        self.rect = self.image.get_rect()
        self.rect[0] = xpos

        if inverted:
            self.image = pygame.transform.flip(self.image, False, True)
            self.rect[1] = - (self.rect[3] - ysize)
        else:
            self.rect[1] = VARIABLES.SH - ysize


        self.mask = pygame.mask.from_surface(self.image)


    def update(self):
        self.rect[0] -= VARIABLES.GSPD



class Ground(pygame.sprite.Sprite):

    def __init__(self, xpos):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('imges/base.png')
        self.image = pygame.transform.scale(self.image, (VARIABLES.GW, VARIABLES.GH))

        self.mask = pygame.mask.from_surface(self.image)

        self.rect = self.image.get_rect()
        self.rect[0] = xpos
        self.rect[1] = VARIABLES.SH - VARIABLES.GH
    def update(self):
        self.rect[0] -= VARIABLES.GSPD

def is_off_screen(sprite):
    return sprite.rect[0] < -(sprite.rect[2])

def get_random_pipes(xpos):
    size = random.randint(100, 300)
    pipe = Pipe(False, xpos, size)
    pipe_inverted = Pipe(True, xpos, VARIABLES.SH - size - VARIABLES.PG)
    return pipe, pipe_inverted


pygame.init()
screen = pygame.display.set_mode((VARIABLES.SW, VARIABLES.SH))
pygame.display.set_caption('T2 BIRD')

BACKGROUND = pygame.image.load('imges/background-day.png')
BACKGROUND = pygame.transform.scale(BACKGROUND, (VARIABLES.SW, VARIABLES.SH))

bird_group = pygame.sprite.Group()
bird = Bird()
bird_group.add(bird)

ground_group = pygame.sprite.Group()

for i in range (2):
    ground = Ground(VARIABLES.GW * i)
    ground_group.add(ground)
BEGIN_IMAGE = pygame.image.load('imges/message.png')
pipe_group = pygame.sprite.Group()
for i in range (2):
    pipes = get_random_pipes(VARIABLES.SW * i + 800)
    pipe_group.add(pipes[0])
    pipe_group.add(pipes[1])



clock = pygame.time.Clock()

begin = True

while begin:

    clock.tick(15)

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
        if event.type == KEYDOWN:
            if event.key == K_SPACE or event.key == K_UP:
                bird.jump()
                begin = False

    screen.blit(BACKGROUND, (0, 0))

    if is_off_screen(ground_group.sprites()[0]):
        ground_group.remove(ground_group.sprites()[0])

        new_ground = Ground(VARIABLES.GW - 20)
        ground_group.add(new_ground)

    bird.start()
    ground_group.update()

    bird_group.draw(screen)
    ground_group.draw(screen)
    screen.blit(BEGIN_IMAGE, (120, 150))
    pygame.display.update()


while True:

    clock.tick(15)

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
        if event.type == KEYDOWN:
            if event.key == K_SPACE or event.key == K_UP:
                bird.jump()

    screen.blit(BACKGROUND, (0, 0))

    if is_off_screen(ground_group.sprites()[0]):
        ground_group.remove(ground_group.sprites()[0])

        new_ground = Ground(VARIABLES.GW - 20)
        ground_group.add(new_ground)

    if is_off_screen(pipe_group.sprites()[0]):
        pipe_group.remove(pipe_group.sprites()[0])
        pipe_group.remove(pipe_group.sprites()[0])

        pipes = get_random_pipes(VARIABLES.SW * 2)

        pipe_group.add(pipes[0])
        pipe_group.add(pipes[1])

    bird_group.update()
    ground_group.update()
    pipe_group.update()

    bird_group.draw(screen)
    pipe_group.draw(screen)
    ground_group.draw(screen)

    pygame.display.update()

    if (pygame.sprite.groupcollide(bird_group, ground_group, False, False, pygame.sprite.collide_mask) or
            pygame.sprite.groupcollide(bird_group, pipe_group, False, False, pygame.sprite.collide_mask)):
        print('game over')
        break

